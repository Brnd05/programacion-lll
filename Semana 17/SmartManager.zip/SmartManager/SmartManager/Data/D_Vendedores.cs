﻿using SmartManager.Data;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace SmartManager.Data
{
    public class D_Vendedores
    {
        public DataTable MostrarVendedores()
        {
            DataTable tabla = new DataTable();
            SqlConnection sqlCon = null;
            SqlDataReader resultado = null;

            try
            {
                sqlCon = Conexion.crearInstancia().CrearConexion();
                sqlCon.Open();

                using (SqlCommand cmd = new SqlCommand("sp_MostrarVendedores", sqlCon))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    resultado = cmd.ExecuteReader();
                    tabla.Load(resultado);
                }
            }
            finally
            {
                if (resultado != null && !resultado.IsClosed) resultado.Close();
                if (sqlCon != null && sqlCon.State == ConnectionState.Open) sqlCon.Close();
            }

            return tabla;
        }

        public bool Login(string usuario, string contraseña)
        {
            DataTable tabla = new DataTable();
            SqlConnection sqlCon = null;
            SqlDataReader resultado = null;

            try
            {
                sqlCon = Conexion.crearInstancia().CrearConexion();
                sqlCon.Open();

                using (SqlCommand cmd = new SqlCommand("sp_IniciarSesion", sqlCon))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Usuario", usuario);
                    cmd.Parameters.AddWithValue("@Contraseña", contraseña);

                    resultado = cmd.ExecuteReader();
                    tabla.Load(resultado); // Cargar resultados en el DataTable

                    if (tabla.Rows.Count > 0)
                    {
                        // Credenciales válidas → abrir SmartManager
                        SmartManager frm = new SmartManager();
                        frm.Show();
                        return true;
                    }
                    else
                    {
                        MessageBox.Show("Usuario o contraseña incorrectos.", "Error de inicio de sesión", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return false;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error en la conexión: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            finally
            {
                if (resultado != null && !resultado.IsClosed)
                    resultado.Close();

                if (sqlCon != null && sqlCon.State == ConnectionState.Open)
                    sqlCon.Close();
            }
        }





    }
}


﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Threading.Tasks;
//using System.Windows.Forms;

//namespace SmartManager
//{
//    internal static class Program
//    {
//        /// <summary>
//        /// Punto de entrada principal para la aplicación.
//        /// </summary>
//        [STAThread]
//        static void Main()
//        {
//            Application.EnableVisualStyles();
//            Application.SetCompatibleTextRenderingDefault(false);
//            Application.Run(new SmartManager());
//        }
//    }
//}

using System;
using System.Windows.Forms;
using SmartManager.Presentation; // Importa el namespace donde está tu Login

namespace SmartManager
{
    internal static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            // Mostrar primero el login
            using (Login loginForm = new Login())
            {
                if (loginForm.ShowDialog() == DialogResult.OK)
                {
                    Application.Run(new SmartManager()); // Solo abre si el login fue correcto
                }
            }
        }
    }
}